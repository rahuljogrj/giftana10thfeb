
import './App.css';
import Navbar from './components/Dashboard/Navbar/Navbar';
import Progressbar from './components/Dashboard/Progressbar/Progressbar';

import Orders from './components/Dashboard/Orders/Orders';
import LastestOrder from './components/Dashboard/LatestOrder/LatestOrder';
import Table2 from './components/Dashboard/Table2/Table2';
import Statistics from './components/Dashboard/Statistics/Statistics';


function App() {
  return (
    <div className="App">

      <Navbar />
      <Progressbar />
      <Orders />
      <Table2 />
      <LastestOrder />
      <Statistics />

    </div>
  );
}

export default App;
