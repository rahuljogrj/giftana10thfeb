const Orders = () => {
    return (
        <div className="cardeffect">
            <div className="orderflex">


                <h2>Orders</h2>

                <div id="myDIV">
                    <button className="orderbuttons active">Today</button>
                    <button className="orderbuttons">Yesterday</button>
                    <button className="orderbuttons">Last 7 days</button>
                    <button className="orderbuttons">Last 28 days</button>
                    <button className="orderbuttons">This year</button>
                </div>
            </div>



            <div className="px-4 pt-2" id="orders-chart-legend">
                <ul className="list-horizontal" >

                    <li className="orderdetails"><span>Complete
                    </span><span>0,00 €</span></li>


                    <li className="orderdetails"><span>Processing
                    </span><span>0,00 €</span></li>


                    <li className="orderdetails"><span>Pending
                    </span><span>0,00 €</span></li>


                    <li className="orderdetails"><span>Cancelled
                    </span><span>0,00 €</span></li>
                    
                </ul>
            </div>

        </div>
    );
}

export default Orders;