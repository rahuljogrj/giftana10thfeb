const Progressbar = () => {
    return (
        <div className="cardeffectpro">
            <h2 style={{marginLeft:'20px'}}>INCOMPLETE ORDERS</h2>
            <div className="container">
                <div>
                    <h3 className="progressname">Today</h3>
                    <div className="progress">
                        <span className="title timer" data-from="0" data-to="85" data-speed="1800">85%</span>
                        <div className="overlay"></div>
                        <div className="left"></div>
                        <div className="right"></div>
                    </div>
                </div>

                <div>
                    <h3 className="progressname">Last 7 Days</h3>
                    <div className="progress">
                        <span className="title timer" data-from="0" data-to="70" data-speed="1500">70%</span>
                        <div className="overlay"></div>
                        <div className="left"></div>
                        <div className="right"></div>
                    </div>
                </div>

                <div>
                    <h3 className="progressname">Last 24 Days</h3>
                    <div className="progress">
                        <span className="title timer" data-from="0" data-to="70" data-speed="1500">70%</span>
                        <div className="overlay"></div>
                        <div className="left"></div>
                        <div className="right"></div>
                    </div>
                </div>

                <div>
                    <h3 className="progressname">This year</h3>
                    <div className="progress">
                        <span className="title timer" data-from="0" data-to="85" data-speed="1800">85%</span>
                        <div className="overlay"></div>
                        <div className="left"></div>
                        <div className="right"></div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Progressbar;