const Table2 = () => {
    return (

        <div className="cardbody1 ">


            <div className="cardeffecttable2">
                <div className="table2grid">
                    <div>
                        <h2>Top components</h2>
                    </div>
                    <div id="myDIV1" style={{ marginTop: '-8px', marginLeft: '50px', }}>
                        <button className="orderbuttons active">By
                            quantity</button>
                        <button className="orderbuttons">By amount</button>
                    </div>
                </div>


                <div>
                    <table>
                        <tr>
                            <th style={{ padding: '10px 70px', float: 'left' }}>Customer</th>
                            <th>Order</th>
                            <th>Amount</th>
                        </tr>

                        <tr>
                            <td style={{ padding: '10px 20px', textAlign: 'left' }}><a href="#">info@smartstore.com</a></td>
                            <td>1</td>
                            <td>52,00 €</td>
                        </tr>

                    </table>
                </div>
            </div>


            <div className="cardeffecttable2">
                <div className="table2grid">
                    <div>
                        <h2>Top components</h2>
                    </div>

                    <div id="myDIV2" style={{ marginTop: '-8px', marginLeft: '50px', }}>
                        <button className="orderbuttons active">By
                            quantity</button>
                        <button className="orderbuttons">By amount</button>
                    </div>
                </div>


                <div>
                    <table>
                        <tr>
                            <th style={{ padding: '10px 70px', float: 'left' }}>Customer</th>
                            <th>Order</th>
                            <th>Amount</th>
                        </tr>

                        <tr>
                            <td style={{ padding: '10px 20px', textAlign: 'left' }}><a href="#">info@smartstore.com</a></td>
                            <td>1</td>
                            <td>52,00 €</td>
                        </tr>

                    </table>
                </div>
            </div>
        </div>


    );
}

export default Table2;