const LastestOrder = () => {
    return (
        <div className="cardeffectLO">
        <div style={{marginTop:'10px', marginBottom:'10px', marginLeft:'20px', marginRight:'20px'}}>
            <h2>Latest Orders</h2>
            <table>
                <tr>
                    <th style={{padding:'10px 100px 10px 20px'}}>Customer</th>
                    <th>Products</th>
                    <th>Amount</th>
                    <th>Order status</th>
                    <th style={{padding:'10px 20px'}}>Order status</th>
                </tr>
                <tr>
                    <td style={{padding:'10px 100px 10px 20px'}}><a href="#">info@smartstore.com</a></td>
                    <td>1</td>
                    <td>52,00 €</td>
                    <td>14-12-2022 08:30:45</td>
                    <td><a href="#">Pending</a></td>
                </tr>
            </table>
        </div>
    </div>
    );
}
 
export default LastestOrder;