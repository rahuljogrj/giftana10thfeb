import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
    return (
        <div className="navbarbody">
            <div className="navflex">
                <img src="https://giftanaindia.com/assets/frontend/images/logo-white.png" className="logo" />


                <div style={{ marginLeft: '-200px' }}>
                    <div className="dropdown">
                        <i href="#" className="fa1 fa fa-home"><br />Dashboard</i>

                    </div>


                    <div className="dropdown">
                        <i className="fa1 fa fa-cube"><br />Catalog</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>
                            <a href="#"><i className="fa3 fa fa-sitemap"></i>Categories</a>
                            <a href="#"><i className="fa3 fa fa-cube"></i>Manage product</a>
                            <a href="#"><i className="fa3 fa fa-star"></i>Product reviews</a>
                            <a href="#"><i className="fa3 fa fa-building"></i>Manufractures</a>
                            <a href="#"><i className="fa3 fa fa-tags"></i>Product tags</a>
                            <a href="#"><i className="fa3 fa fa-arrow-down"></i>Low stock report</a>
                            <hr />
                            <h4>Atrributes</h4>
                            <a href="#"><i className="fa3 fa fa-list"></i>Product attributes</a>
                            <a href="#"><i className="fa3 fa fa-list"></i>Specification attributes</a>
                            <a href="#"><i className="fa3 fa fa-list"></i>Checkedout attributes</a>
                        </div>
                    </div>



                    <div className="dropdown">
                        <i className="fa1 fa fa-signal"><br />sales</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>
                            <a href="#"><i className="fa3 fa fa-sitemap"></i>Orders</a>
                            <a href="#"><i className="fa3 fa fa-truck"></i>Shipments</a>
                            <a href="#"><i className="fa3 fa fa-recycle"></i>Recurring payment</a>
                            <a href="#"><i className="fa3 fa fa-truck"></i>Return request</a>
                            <a href="#"><i className="fa3 fa fa-gift"></i>Gift cards</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-shopping-cart"></i>Current shopping cards</a>
                            <a href="#"><i className="fa3 fa fa-heart"></i>Current wishlists</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-thumbs-up"></i>Bestsellers</a>
                            <a href="#"><i className="fa3 fa fa-thumbs-down"></i>Product never purchased</a>

                        </div>
                    </div>




                    <div className="dropdown">
                        <i className="fa1 fa fa-user-plus"><br />Customers</i>

                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>
                            <a href="#"><i className="fa3 fa fa-user-o"></i>Customers</a>
                            <a href="#"><i className="fa3 fa fa-users"></i>Customers roles</a>
                            <a href="#"><i className="fa3 fa fa-user-o"></i>Online customers</a>
                            <a href="#"><i className="fa3 fa fa-signal"></i>Customer report</a>
                            <a href="#"><i className="fa3 fa fa-facebook"></i>External authentication methods</a>

                            <hr />

                            <a href="#"><i className="fa3 fa fa-eye"></i>Activity Log</a>

                        </div>
                    </div>



                    <div className="dropdown">
                        <i className="fa1 fa fa-bullhorn"><br />Promotion</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>
                            <a href="#"><i className="fa3 fa fa-percent"></i>Discounts</a>
                            <a href="#"><i className="fa3 fa fa-users"></i>Affiliates</a>
                            <a href="#"><i className="fa3 fa fa-envelope"></i>Newsletter subscribers</a>
                            <a href="#"><i className="fa3 fa fa-bullhorn"></i>Campaigns</a>

                        </div>
                    </div>



                    <div className="dropdown">
                        <i className="fa1 fa fa-sitemap"><br />CMS</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>
                            <a href="#"><i className="fa3 fa fa-file"></i>Topics</a>
                            <a href="#"><i className="fa3 fa fa-film"></i>Page builder</a>
                            <a href="#"><i className="fa3 fa fa-film"></i>media</a>
                            <a href="#"><i className="fa3 fa fa-square"></i>Content slider</a>
                            <a href="#"><i className="fa3 fa fa-list"></i>Menus</a>
                            <div className="dropdown1">
                                <a href="#"><i className="fa3 fa fa-rectangle-ad"></i>News <i className="sub-submenu fa3 fa fa-angle-right"
                                ></i></a>
                                <div className="dropdown1-content">
                                    <a href="#">News item</a>
                                    <a href="#">News comments</a>
                                </div>
                            </div>



                            <div className="dropdown1">
                                <a href="#"><i className="fa3 fa fa-rss"></i>Blog<i className="sub-submenu fa3 fa fa-angle-right"
                                ></i></a>
                                <div className="dropdown1-content">
                                    <a href="#">Blog posts</a>
                                    <a href="#">Blog comments</a>

                                </div>
                            </div>

                            <a href="#"><i className="fa3 fa fa-wpforms"></i>Forums</a>
                            <a href="#"><i className="fa3 fa fa-list"></i>Message templates</a>
                            <a href="#"><i className="fa3 fa fa-check"></i>Polls</a>
                            <a href="#"><i className="fa3 fa fa-film"></i>Widgets</a>
                        </div>
                    </div>



                    <div className="dropdown">
                        <i className="fa1 fa fa-gear"><br />Configuration</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>

                            <a href="#"><i className="fa3 fa fa-sitemap"></i>Setting</a>
                            <a href="#"><i className="fa3 fa fa-home"></i>Stores</a>
                            <div className="dropdown1">
                                <a href="#"><i className="fa3 fa fa-globe"></i>Regional setting<i className="sub-submenu fa3 fa fa-angle-right"
                                ></i></a>
                                <div className="dropdown1-content">
                                    <a href="#">Countries</a>
                                    <a href="#">Languages</a>
                                    <a href="#">Currencies</a>
                                    <hr />
                                    <h4 style={{color:'rgb(185, 170, 170)', marginLeft:'10px'}}>SHIPPING</h4>
                                    <a href="#">Shipping methods</a>
                                    <a href="#">Shipping rate computation methods</a>
                                    <hr />
                                    <h4 style={{color:'rgb(185, 170, 170)', marginLeft:'10px'}}>TAX</h4>
                                    <a href="#">Tax provider</a>
                                    <a href="#">Tax categories</a>

                                </div>
                            </div>

                            <a href="#"><i className="fa3 fa fa-building"></i>Payments methods</a>

                            <div className="dropdown1">
                                <a href="#"><i className="fa3 fa fa-tags"></i>Lists<i className="sub-submenu fa3 fa fa-angle-right"></i></a>
                                <div className="dropdown1-content">
                                    <a href="#">Delivery times</a>
                                    <a href="#">Quantity units</a>
                                    <a href="#">Weights</a>
                                    <a href="#">Dimensions</a>
                                    <a href="#">Price lables</a>



                                </div>
                            </div>
                            <a href="#"><i className="fa3 fa fa-arrow-down"></i>Email Accounts</a>
                            <a href="#"><i className="fa3 fa fa-eye"></i>Activity Types</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-download"></i>Import</a>
                            <a href="#"><i className="fa3 fa fa-upload"></i>Export</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-brush"></i>Themes</a>
                        </div>
                    </div>



                    <div className="dropdown">
                        <i className="fa1 fa fa-database"><br />System</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>

                            <a href="#"><i className="fa3 fa fa-filter"></i>Rules</a>
                            <a href="#"><i className="fa3 fa fa-cube"></i>Log</a>
                            <a href="#"><i className="fa3 fa fa-inbox"></i>Message Queue</a>
                            <a href="#"><i className="fa3 fa fa-clock"></i>Scheduled tasks</a>
                            <a href="#"><i className="fa3 fa fa-search"></i>SEO names</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-wrench"></i>Maintenance</a>
                            <a href="#"><i className="fa3 fa fa-warning"></i>Warnings</a>
                            <a href="#"><i className="fa3 fa fa-info"></i>System information</a>

                        </div>
                    </div>




                    <div className="dropdown">
                        <i className="fa1 fa fa-puzzle-piece"><br />Plugins</i>
                        <div className="dropdown-content">
                            <i className="caretstyle fa fa-caret-up"></i>

                            <a href="#"><i className="fa3 fa fa-telegram"></i>Clickatell SMS provider</a>
                            <a href="#"><i className="fa3 fa fa-code"></i>Developer tools</a>
                            <a href="#"><i className="fa3 fa fa-star"></i>GDPR</a>
                            <a href="#"><i className="fa3 fa fa-google"></i>Google merchant center feed</a>
                            <a href="#"><i className="fa3 fa fa-file"></i>Megamenu</a>
                            <a href="#"><i className="fa3 fa fa-search"></i>Megasearch</a>
                            <a href="#"><i className="fa3 fa fa-list-ol"></i>Number formatter</a>
                            <a href="#"><i className="fa3 fa fa-list"></i>Output cache</a>
                            <a href="#"><i className="fa3 fa fa-search"></i>Search log</a>
                            <a href="#"><i className="fa3 fa fa-image"></i>Tinyimage</a>
                            <a href="#"><i className="fa3 fa fa-square-right"></i>Url rewriter</a>
                            <hr />
                            <a href="#"><i className="fa3 fa fa-puzzle-piece"></i>Manage plugins</a>
                        </div>
                    </div>
                </div>


                <div style={{ marginRight: '30px' }}>

                    <i className="fa2 fa fa-gear"></i>
                    <i className="fa2 fa fa-globe"></i>
                    <i className="fa2 fa fa-info"></i>
                    <i className="fa2 fa fa-user-o"></i>

                </div>



            </div>


        </div>
    );
}

export default Navbar;