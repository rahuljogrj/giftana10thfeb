
var header = document.getElementById("myDIV2");
var btns = header.getElementsByClassName("orderbuttons1");
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("active1");
        current[0].className = current[0].className.replace(" active1", "");
        this.className += " active1";
    });
}






// Add active class to the current button (highlight it)
var header = document.getElementById("myDIV1");
var btns = header.getElementsByClassName("orderbuttons");
for (var i = 0; i < btns.length; i++) {
    btns[i].addEventListener("click", function () {
        var current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
    });
}