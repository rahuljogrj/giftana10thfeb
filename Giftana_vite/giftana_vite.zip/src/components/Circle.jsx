import React from 'react';
import "../assets/css/Circles.css";


import { useNavigate } from "react-router-dom";




const Circle = () => {
    const navigate = useNavigate();
    const categories = () => { navigate("/categories") }





    return (
        <div className="circlesdiv flex justify-between ...">
            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>

            <div className="circles"><a href="/subcategories"><img src="../public/Images/img.jpg" className="circlesimg" />
                <p className="circletext">Mobiles</p></a></div>




            {/* <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div>
            <div className="circles"></div> */}
        </div>

    )
}

export default Circle