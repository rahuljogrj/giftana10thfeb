import React from 'react'
import "../assets/css/SecondBanner.css";


const SecondBanner = () => {
  return (
    <div>
    <img class="secondbanner"
      src="https://static3.depositphotos.com/1000454/256/i/450/depositphotos_2567474-stock-photo-wide-panorama-of-french-alps.jpg" />
  </div>
  )
}

export default SecondBanner